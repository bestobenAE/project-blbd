import { StatusBar } from "expo-status-bar";
import { StyleSheet } from "react-native";
import RegisterScreen from "./screens/RegisterScreen";
import LoginScreen from "./screens/LoginScreen";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { NavigationContainer } from "@react-navigation/native";
import UserTabs from "./screens/dashboard/UserTabs";
import HospitalTab from "./screens/dashboard/HospitalTab"; // Import HospitalTab

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="UserTabs" component={UserTabs} options={{ headerShown: false }} />
        <Stack.Screen name="HospitalTab" component={HospitalTab} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
