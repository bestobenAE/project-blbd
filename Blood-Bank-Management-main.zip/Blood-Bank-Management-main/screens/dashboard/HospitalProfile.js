import React, { useEffect, useState } from "react";
import { View, Text, ActivityIndicator, StyleSheet, Button } from "react-native";
import { Card } from "react-native-paper";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "../../services/firebaseAuth";
import { signOut } from "firebase/auth";

export default function HospitalProfile({ navigation }) {
  const [hospitalData, setHospitalData] = useState(null);
  const [loading, setLoading] = useState(true);
  const user = auth.currentUser;

  useEffect(() => {
    const fetchHospitalData = async () => {
      try {
        const hospitalRef = doc(db, "hospitals", user.uid);
        const hospitalSnap = await getDoc(hospitalRef);
        if (hospitalSnap.exists()) {
          setHospitalData(hospitalSnap.data());
        } else {
          console.log("No hospital found");
        }
      } catch (error) {
        console.error("Error fetching hospital data: ", error);
      } finally {
        setLoading(false);
      }
    };
    fetchHospitalData();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigation.replace("Login");
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };

  if (loading) {
    return <ActivityIndicator size="large" color="#d32f2f" style={styles.loader} />;
  }

  return (
    <View style={styles.container}>
      <Card style={styles.card}>
        <Text style={styles.title}>Hospital Profile</Text>
        {hospitalData ? (
          <>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.value}>{hospitalData.hospitalName}</Text>
            <Text style={styles.label}>Email:</Text>
            <Text style={styles.value}>{hospitalData.email}</Text>
            <Text style={styles.label}>Location:</Text>
            <Text style={styles.value}>{hospitalData.location}</Text>
          </>
        ) : (
          <Text style={styles.noData}>No hospital data found</Text>
        )}
      </Card>
      <Button title="Logout" onPress={handleLogout} color="#d32f2f" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff5f5",
    padding: 20,
  },
  loader: {
    marginTop: 50,
  },
  card: {
    padding: 20,
    borderRadius: 10,
    backgroundColor: "#ffffff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    width: "90%",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#d32f2f",
    textAlign: "center",
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginTop: 10,
  },
  value: {
    fontSize: 16,
    color: "#555",
  },
  noData: {
    fontSize: 16,
    color: "#999",
    textAlign: "center",
    marginTop: 20,
  },
});

