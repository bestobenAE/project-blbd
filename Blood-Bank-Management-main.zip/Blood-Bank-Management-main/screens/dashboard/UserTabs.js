import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import UserPage from "./UserPage";
import UserProfile from "../UserProfile";
import LeaderboardPage from "./LeaderboardPage";  // ✅ New Tab
import ChatPage from "./ChatPage";  // ✅ New Tab

const Tab = createBottomTabNavigator();

export default function UserTabs({ route }) {
  const { user } = route.params; // Pass user data from login

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === "UserPage") {
            iconName = "home";
          } else if (route.name === "UserProfile") {
            iconName = "person";
          } else if (route.name === "LeaderboardPage") {
            iconName = "trophy";
          } else if (route.name === "ChatPage") {
            iconName = "chatbubbles";
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#007bff",
        tabBarInactiveTintColor: "gray",
        tabBarStyle: { backgroundColor: "#fff", paddingBottom: 5, height: 60 },
      })}
    >
      <Tab.Screen name="UserPage" component={UserPage} initialParams={{ user }} />
      <Tab.Screen name="LeaderboardPage" component={LeaderboardPage} initialParams={{ user }} />
      <Tab.Screen name="ChatPage" component={ChatPage} initialParams={{ user }} />
      <Tab.Screen name="UserProfile" component={UserProfile} initialParams={{ user }} />
    </Tab.Navigator>
  );
}
