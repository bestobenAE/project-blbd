import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import { db } from "../../services/firebaseAuth"; // Ensure you have configured Firebase correctly

export default function LeaderboardPage() {
  const [donors, setDonors] = useState([]);

  useEffect(() => {
    const fetchTopDonors = async () => {
      try {
        const usersRef = collection(db, "users");
        const q = query(usersRef, orderBy("totalDonations", "desc"), limit(10));
        const querySnapshot = await getDocs(q);
        
        const fetchedDonors = querySnapshot.docs.map(doc => ({
          id: doc.id,
          name: doc.data().userName,
          donations: doc.data().totalDonations || 0,
        }));

        setDonors(fetchedDonors);
      } catch (error) {
        console.error("Error fetching donors:", error);
      }
    };

    fetchTopDonors();
  }, []);

  const renderItem = ({ item, index }) => {
    const bloodLiters = (item.donations * 0.5).toFixed(1); // 0.5L per donation
    return (
      <View style={styles.item}>
        <Text style={styles.rank}>{index + 1}.</Text>
        <View style={styles.details}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.donations}>
            {item.donations} donations | {bloodLiters}L donated
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Leaderboard</Text>
      <FlatList
        data={donors}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f5f5f5",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  rank: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#ff5733",
  },
  details: {
    flex: 1,
    marginLeft: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: "500",
  },
  donations: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#4CAF50",
  },
});
