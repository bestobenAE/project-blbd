import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import HospitalPage from './HospitalPage';
import ManagementPage from './ManagementPage';
import HospitalProfile from './HospitalProfile';
import ChatPage from './ChatPage';

const Tab = createBottomTabNavigator();

export default function HospitalTab() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen
        name="HospitalPage"
        component={HospitalPage}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => <MaterialIcons name="local-hospital" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="ManagementPage"
        component={ManagementPage}
        options={{
          tabBarLabel: 'Management',
          tabBarIcon: ({ color, size }) => <FontAwesome5 name="clipboard-list" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="ChatPage"
        component={ChatPage}
        options={{
          tabBarLabel: 'Chat',
          tabBarIcon: ({ color, size }) => <MaterialIcons name="chat" size={size} color={color} />,
        }}
      />
      <Tab.Screen
        name="HospitalProfile"
        component={HospitalProfile}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => <FontAwesome5 name="user" size={size} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}
