import React, { useEffect, useState } from 'react';
import { Alert, FlatList, Text, View, ActivityIndicator, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { collection, query, where, getDocs, updateDoc, doc, deleteDoc, increment } from 'firebase/firestore';
import { auth, db } from '../../services/firebaseAuth';
import * as Location from 'expo-location';

export default function UserPage({ route }) {
  const { user } = route.params;
  const [pendingRequests, setPendingRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState(null);
  const [acceptedRequest, setAcceptedRequest] = useState(null);

  useEffect(() => {
    const fetchLocation = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        Alert.alert("Permission Denied", "Location access is required.");
        return;
      }

      let loc = await Location.getCurrentPositionAsync({});
      setLocation(loc.coords);

      const currentUser = auth.currentUser;
      if (currentUser) {
        await updateDoc(doc(db, "users", currentUser.uid), {
          location: {
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
          },
        });
      }
    };

    const fetchPendingRequests = async () => {
      try {
        const q = query(
          collection(db, "requests"),
          where("donorEmail", "==", user.email),
          where("status", "==", false)
        );
        const querySnapshot = await getDocs(q);
        const requests = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setPendingRequests(requests);
      } catch (error) {
        console.error("Error fetching requests: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLocation();
    fetchPendingRequests();
  }, []);

  const handleAcceptRequest = async (request) => {
    try {
      const requestorEmail = request.requesterEmail;
      const userQuery = query(collection(db, "users"), where("email", "==", requestorEmail));
      const userSnapshot = await getDocs(userQuery);

      if (!userSnapshot.empty) {
        const requestorData = userSnapshot.docs[0].data();

        if (requestorData.location) {
          const requestorLocation = {
            latitude: requestorData.location.latitude,
            longitude: requestorData.location.longitude,
          };

          await updateDoc(doc(db, "requests", request.id), { status: true });

          const userRef = doc(db, "users", auth.currentUser.uid);
          await updateDoc(userRef, { totalDonations: increment(1) });

          setAcceptedRequest({ ...request, requestorLocation });

          Alert.alert("Success", "Request accepted!");
          setPendingRequests(pendingRequests.filter(r => r.id !== request.id));
        } else {
          Alert.alert("Error", "Requestor's location is not available.");
        }
      } else {
        Alert.alert("Error", "Requestor not found.");
      }
    } catch (error) {
      Alert.alert("Error", "Failed to accept request.");
      console.error("Error accepting request:", error);
    }
  };

  const handleDeclineRequest = async (request) => {
    try {
      await deleteDoc(doc(db, "requests", request.id));

      setPendingRequests(pendingRequests.filter(r => r.id !== request.id));

      Alert.alert("Declined", "The request has been removed.");
    } catch (error) {
      Alert.alert("Error", "Failed to decline request.");
      console.error("Error declining request:", error);
    }
  };

  const handleNavigateToRequestor = () => {
    if (acceptedRequest && acceptedRequest.requestorLocation) {
      const { latitude, longitude } = acceptedRequest.requestorLocation;
      const url = `https://www.google.com/maps?q=${latitude},${longitude}`;
      Linking.openURL(url);
    } else {
      Alert.alert("Location not available", "Requestor's location is missing.");
    }
  };

  const handleShowRequestorEmail = () => {
    if (acceptedRequest) {
      Alert.alert("Requestor Email", acceptedRequest.requesterEmail);
    }
  };

  return (
    <View style={styles.container}>
      {location ? (
        <Text style={styles.text}>Latitude: {location.latitude}, Longitude: {location.longitude}</Text>
      ) : (
        <Text style={styles.text}>Fetching location...</Text>
      )}

      <Text style={styles.subHeader}>Pending Requests</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#007BFF" />
      ) : pendingRequests.length === 0 ? (
        <Text style={styles.text}>No pending requests.</Text>
      ) : (
        <FlatList
          data={pendingRequests}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.requestItem}>
              <Text style={styles.text}>Blood Type: {item.bloodType}</Text>
              <Text style={styles.text}>Requester: {item.requesterEmail}</Text>
              <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.acceptButton} onPress={() => handleAcceptRequest(item)}>
                  <Text style={styles.buttonText}>Accept</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.declineButton} onPress={() => handleDeclineRequest(item)}>
                  <Text style={styles.buttonText}>Decline</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}

      {acceptedRequest && (
        <View style={styles.extraButtons}>
          <TouchableOpacity style={styles.navigateButton} onPress={handleNavigateToRequestor}>
            <Text style={styles.buttonText}>Navigate to Requestor</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.emailButton} onPress={handleShowRequestorEmail}>
            <Text style={styles.buttonText}>Show Requestor Email</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f8f9fa' },
  text: { fontSize: 16, marginBottom: 5, color: '#212529' },
  subHeader: { fontSize: 18, fontWeight: 'bold', marginVertical: 10, color: '#495057' },
  requestItem: { padding: 15, backgroundColor: 'white', borderRadius: 8, borderWidth: 1, borderColor: '#dee2e6', marginBottom: 10 },
  buttonContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  acceptButton: { backgroundColor: '#007BFF', padding: 10, borderRadius: 5, alignItems: 'center', flex: 1, marginRight: 5 },
  declineButton: { backgroundColor: '#dc3545', padding: 10, borderRadius: 5, alignItems: 'center', flex: 1, marginLeft: 5 },
  navigateButton: { backgroundColor: '#28a745', padding: 10, borderRadius: 5, alignItems: 'center', marginTop: 10 },
  emailButton: { backgroundColor: '#ffc107', padding: 10, borderRadius: 5, alignItems: 'center', marginTop: 10 },
  buttonText: { color: '#fff', fontWeight: 'bold' },
  extraButtons: { marginTop: 20 }
});
