import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Button, StyleSheet, View, Text } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { signOut } from 'firebase/auth';
import { collection, query, where, onSnapshot, addDoc } from 'firebase/firestore';
import { auth, db } from '../../services/firebaseAuth';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';

const haversineDistance = (lat1, lon1, lat2, lon2) => {
  const toRad = (angle) => (Math.PI / 180) * angle;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export default function HospitalPage({ route, navigation }) {
  const { user } = route?.params || {};
  const [location, setLocation] = useState(null);
  const [donorLocations, setDonorLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedBloodType, setSelectedBloodType] = useState('All');

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigation.replace('Login');
    } catch (error) {
      console.error('Error signing out: ', error);
    }
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => <Button title="Logout" onPress={handleLogout} color="#D9534F" />,
    });
  }, [navigation]);

  const sendRequest = async (donor) => {
    try {
      const requestData = {
        bloodType: donor.bloodType,
        requesterEmail: user?.email || auth.currentUser?.email,
        donorEmail: donor.email,
        status: false,
        timestamp: new Date(),
      };
      await addDoc(collection(db, 'requests'), requestData);
      Alert.alert('Success', 'Request sent successfully!');
    } catch (error) {
      console.error('Error sending request: ', error);
      Alert.alert('Error', 'Failed to send request.');
    }
  };

  useEffect(() => {
    const fetchLocationAndTrackDonors = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Location access is required.');
        setLoading(false);
        return;
      }

      let loc = await Location.getCurrentPositionAsync({});
      const hospitalLocation = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      setLocation({
        ...hospitalLocation,
        latitudeDelta: 0.05,
        longitudeDelta: 0.02,
      });

      const donorsQuery = query(collection(db, 'users'), where('role', '==', 'donor'));
      const unsubscribe = onSnapshot(donorsQuery, (snapshot) => {
        const donors = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          if (data.location) {
            const distance = haversineDistance(
              hospitalLocation.latitude,
              hospitalLocation.longitude,
              data.location.latitude,
              data.location.longitude
            );
            donors.push({
              id: doc.id,
              latitude: data.location.latitude,
              longitude: data.location.longitude,
              bloodType: data.bloodType || 'Unknown',
              email: data.email || 'No Email',
              distance: distance,
            });
          }
        });
        donors.sort((a, b) => a.distance - b.distance);
        setDonorLocations(donors);
        setLoading(false);
      });

      return () => unsubscribe();
    };
    fetchLocationAndTrackDonors();
  }, []);

  const filteredDonors = selectedBloodType === 'All'
    ? donorLocations
    : donorLocations.filter((donor) => donor.bloodType === selectedBloodType);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nearest Donor</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#FF5733" />
      ) : (
        <>
          <MapView
            style={styles.map}
            region={location ?? undefined}
            showsUserLocation={true}
            followsUserLocation={true}
            loadingEnabled={true}
          >
            {location && <Marker coordinate={location} title="Your Location" />}
            {filteredDonors.map((donor, index) => (
              <Marker
                key={donor.id}
                coordinate={{ latitude: donor.latitude, longitude: donor.longitude }}
                title={`Donor (${donor.bloodType})`}
                description={`Email: ${donor.email} | Distance: ${donor.distance.toFixed(2)} km`}
                pinColor={index < 3 ? 'green' : 'red'}
                onPress={() => {
                  Alert.alert(
                    `Donor Details (${donor.bloodType})`,
                    `Email: ${donor.email}\nDistance: ${donor.distance.toFixed(2)} km`,
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Send Request', onPress: () => sendRequest(donor) },
                    ]
                  );
                }}
              />
            ))}
          </MapView>

          <Picker
            selectedValue={selectedBloodType}
            style={styles.picker}
            onValueChange={(itemValue) => setSelectedBloodType(itemValue)}
          >
            <Picker.Item label="All Blood Types" value="All" />
            <Picker.Item label="A+" value="A+" />
            <Picker.Item label="A-" value="A-" />
            <Picker.Item label="B+" value="B+" />
            <Picker.Item label="B-" value="B-" />
            <Picker.Item label="O+" value="O+" />
            <Picker.Item label="O-" value="O-" />
            <Picker.Item label="AB+" value="AB+" />
            <Picker.Item label="AB-" value="AB-" />
          </Picker>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 10,
  },
  picker: {
    height: 60,
    marginTop: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
  },
  map: {
    flex: 1,
    width: '100%',
    borderRadius: 10,
  },
});