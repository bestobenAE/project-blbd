import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, TouchableOpacity, StyleSheet } from "react-native";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { collection, doc, setDoc } from "firebase/firestore";
import { auth, db } from "../services/firebaseAuth";
import { Picker } from "@react-native-picker/picker";
import { getDoc } from "firebase/firestore";

const RegisterScreen = ({ navigation }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [bloodType, setBloodType] = useState("");
    const [userName, setUserName] = useState("");

    const handleRegister = async () => {
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
                
            await setDoc(doc(collection(db, "users"), user.uid), {
                email: email,
                role: "donor",
                bloodType: bloodType,
                userName: userName,
            });

            const userDocRef = doc(db, "users", user.uid);
            const userDoc = await getDoc(userDocRef);
            const userData = userDoc.data();
                
            Alert.alert("Registration Successful");
            navigation.replace("UserTabs", { user: userData });
        } catch (error) {
            console.error("Error registering user:", error);
            Alert.alert("Registration Failed", error.message);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Register</Text>

            <TextInput 
                style={styles.input} 
                placeholder="Email" 
                value={email} 
                onChangeText={setEmail} 
                keyboardType="email-address"
            />
            <TextInput 
                style={styles.input} 
                placeholder="Name" 
                value={userName} 
                onChangeText={setUserName} 
                keyboardType="email-address"
            />
            <TextInput 
                style={styles.input} 
                placeholder="Password" 
                value={password} 
                onChangeText={setPassword} 
                secureTextEntry 
            />
            <Text style={styles.label}>Blood Type</Text>
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={bloodType}
                    style={styles.picker}
                    onValueChange={(itemValue) => setBloodType(itemValue)}
                >
                    <Picker.Item label="A+" value="A+" />
                    <Picker.Item label="A-" value="A-" />
                    <Picker.Item label="B+" value="B+" />
                    <Picker.Item label="B-" value="B-" />
                    <Picker.Item label="O+" value="O+" />
                    <Picker.Item label="O-" value="O-" />
                    <Picker.Item label="AB+" value="AB+" />
                    <Picker.Item label="AB-" value="AB-" />
                </Picker>
            </View>
            <TouchableOpacity style={styles.button} onPress={handleRegister}>
                <Text style={styles.buttonText}>Register</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.replace("Login")}>
                <Text style={styles.link}>Back to Login</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#f5f5f5",
        padding: 20,
        justifyContent: "center",
        alignItems: "center",
    },
    title: {
        fontSize: 28,
        fontWeight: "bold",
        marginBottom: 20,
        color: "#333",
    },
    input: {
        width: "100%",
        height: 50,
        backgroundColor: "#fff",
        borderRadius: 10,
        paddingHorizontal: 15,
        fontSize: 16,
        marginBottom: 15,
        borderWidth: 1,
        borderColor: "#ddd",
    },
    button: {
        width: "100%",
        backgroundColor: "#007bff",
        padding: 15,
        borderRadius: 10,
        alignItems: "center",
    },
    buttonText: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#fff",
    },
    link: {
        marginTop: 15,
        fontSize: 16,
        color: "#007bff",
    },
    label: {
        fontSize: 16,
        marginBottom: 8,
        color: "#333",
    },
    pickerContainer: {
        width: "100%",
        height: 50,
        backgroundColor: "#fff",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#ddd",
        marginBottom: 15,
        justifyContent: "center",
    },
    picker: {
        width: "100%",
        height: 50,
    },
});

export default RegisterScreen;