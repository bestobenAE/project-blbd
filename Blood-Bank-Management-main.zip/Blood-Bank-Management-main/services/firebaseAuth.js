import { initializeApp } from "firebase/app";
import { getAuth, initializeAuth, getReactNativePersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import ReactNativeAsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
    apiKey: "AIzaSyDD9D4PC4kMrG5kre7akCSkmfdr0mlkZ9M",
    authDomain: "react-native-auth-e4679.firebaseapp.com",
    projectId: "react-native-auth-e4679",
    storageBucket: "react-native-auth-e4679.appspot.com",
    messagingSenderId: "852339588564",
    appId: "1:852339588564:web:62ea689780af8d852a6a41"
};

const app = initializeApp(firebaseConfig);

// 🔹 Initialize Firebase Authentication
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage),
});

// 🔹 Initialize Firestore
const db = getFirestore(app);

// 🔹 Debugging logs to check initialization
console.log("Firestore initialized:", db);
console.log("Auth initialized:", auth);

export { auth, db };
